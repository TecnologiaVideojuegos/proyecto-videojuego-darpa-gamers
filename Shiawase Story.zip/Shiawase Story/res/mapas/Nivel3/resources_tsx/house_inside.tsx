<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.2" tiledversion="1.2.3" name="house_inside" tilewidth="32" tileheight="32" tilecount="224" columns="16">
 <image source="../house_inside.png" width="512" height="448"/>
</tileset>
