<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.2" tiledversion="1.2.3" name="city_outside" tilewidth="32" tileheight="32" tilecount="432" columns="24">
 <image source="../../resource_png/city_outside.png" width="768" height="576"/>
</tileset>
