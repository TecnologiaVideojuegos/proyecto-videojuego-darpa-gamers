<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.2" tiledversion="1.2.3" name="casa_madera" tilewidth="32" tileheight="32" tilecount="117" columns="9">
 <image source="../../resource_png/casa_madera.png" width="288" height="416"/>
</tileset>
