<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.2" tiledversion="1.2.3" name="cavern_ruins" tilewidth="32" tileheight="32" tilecount="384" columns="24">
 <image source="../../resource_png/cavern_ruins.png" width="768" height="512"/>
</tileset>
