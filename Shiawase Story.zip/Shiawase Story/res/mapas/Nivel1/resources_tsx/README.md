Aquí van los recursos tsx utilizados para crear los mapas en Tiled
