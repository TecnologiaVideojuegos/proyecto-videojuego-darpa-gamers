Aquí van los layout tmx hechos con tiled
